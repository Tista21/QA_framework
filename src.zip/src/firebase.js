import * as firebase from 'firebase';
// import {getDatabase} from  './firebase/database';
import './firebase/database';



const firebaseConfig = {
  apiKey: "AIzaSyC0OmKMMbrKQ3IzgM0asegTDuuEomE7hU4",
  authDomain: "dashboard-64ec2.firebaseapp.com",
  databaseURL: "https://dashboard-64ec2-default-rtdb.firebaseio.com",
  projectId: "dashboard-64ec2",
  storageBucket: "dashboard-64ec2.appspot.com",
  messagingSenderId: "162685498771",
  appId: "1:162685498771:web:7ed166487c3d8713526466"
  };

  //  firebase.initializeapp(firebaseConfig)
  //  const databaseRef = firebase.database().ref()
  //  export const loginRef = databaseRef.child()
 export const firebaseApp = firebase.initializeApp(firebaseConfig);
 
 export default firebase;
  //  export const database = getDatabase();
 // Initialize Firebase
 // const app = initializeApp(firebaseConfig);
//const db = getDatabase(app);

//  export { db };
