import { LockOutlined, UserOutlined } from '@ant-design/icons';
import { Checkbox, Form, Input } from 'antd';
import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.css';
// import { firebaseApp } from './firebase.js';


function  Registrationlogin () {
  const [login,setlogin] = useState("")
  const  onFinish = (e) => {
    e.preventDefault()
    const item = {
      task: login,

       
    }
    // firebaseApp.push(item)
    // setlogin("")
    //console.log('Received values of form: ', values);
  };

  return (
    <center><Form
      name="normal_login"
      className="box"
      initialValues={{
        remember: true,
      }}
      onFinish={onFinish} 
    >

      <Form.Item
          name="username" 
          rules={[
          {
            required: true,
            message: 'Please input your Username!',
          },
        ]}
      >
        <Input prefix={<UserOutlined className="site-form-item-icon" />} placeholder="Username" />
      </Form.Item>
      <Form.Item
        name="password"
        rules={[
          {
            required: true,
            message: 'Please input your Password!',
          },
        ]}
      >
        <Input
          prefix={<LockOutlined className="site-form-item-icon" />}
          type="password"
          placeholder="Password"
        />
      </Form.Item>
      <Form.Item>
        <Form.Item name="remember" valuePropName="checked" noStyle>
          <Checkbox>Remember me</Checkbox>
        </Form.Item>

        <a className="login-form-forgot" href="" onClick="return openForm()">
          Forgot password
        </a>
      </Form.Item>

      <Form.Item>
        <button type="text" htmlType="submit" variant="success" className="login-form-button" class='button' value ={onFinish}  onChange={(e) => setlogin(e.target.value)}>
        Log in
        </button>
        Or 
        <a href = "" onClick="return openForm()" >Register now!</a>
      </Form.Item>
    </Form>
    </center>
  );
};

export default Registrationlogin;
