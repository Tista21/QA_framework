import React from 'react';
import './App.css';
import Registrationlogin  from './component/Registration.js';


function App(){

    return (
        <div>
            <Registrationlogin/>
            <div  container="row row fluid" id="main">
             
            </div>
        </div>
    )
}

export default App
