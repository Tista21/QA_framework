import xml.etree.ElementTree as ET
import matplotlib.pyplot as plt
import streamlit as st
from xml.dom import minidom
import xmltodict
import json
import plotly as plt
import plotly.graph_objects as go
import plotly.express as px



st.set_page_config(page_title="Dashboard ", page_icon=":chart_with_upwards_trend", layout="wide")
data = {}
success = 0
failure = 0


#-------header_section------

st.title("Welcome to the Dashboard")
st.subheader("Browse to choose your XML file")


with st.container():
    uploaded_file = st.sidebar.file_uploader("Upload File",type=['xml'])

    print(uploaded_file)      
    if (uploaded_file):
        xmlFile = uploaded_file.read()
        file1_data = json.loads(json.dumps(xmltodict.parse(xmlFile)))
        print('data')
        print(file1_data)
        
        print(1)
        st.write("FileName: ",uploaded_file.name)
        print(2)
        st.write("FileType: ", uploaded_file.type)
        print(3)
        st.write("FileSize: ", uploaded_file.size)        
        print(4,uploaded_file)
        
        #with open(uploaded_file) as xml_file:
        # data = json.load(uploaded_file)

        with st.expander("See test stages"): 
            print(5)
            try:
                for each in file1_data['testsuite']['testcase']:
                    isSuccess = each['@classname'] == 'com.auction.verifications.Feeds'
                    output= ''
                    if(isSuccess):
                            success += 1
                            output = 'SUCCESS'
                    else:
                            failure += 1
                            outptut = 'FAIL'
                    print(6)
                st.write("* ", each['@classname'])
                st.write("> ", output)    

            except:                   
                for each in file1_data['suite']['parameter']:
                    isSuccess = each['@name'] =='selenium.host','selenium.port','selenium.browser','selenium.url'

                    output= ''

                    if(isSuccess):
                        success += 1  
                        output = 'Success'
                    else:
                        failure += 1
                        output = 'Fail' 
                    print(7)

                st.write("* ", each['@name'])
                st.write("> ", output)

            else:
                for each in file1_data['testsuite']['testcase']:
                    isSuccess = each['@classname'] == 'com.auction.verifications.BugScripts'

                    output = 'Fail'

                    # if(isSuccess):
                    #     success +=1
                    #     outptut = 'Succes'
                    # else:
                    #     failure += 1
                    #     outptut = 'Fail'
                    print(8)               
                st.write('*', each['@classname'])
                st.write(">",output)
        # data_frame = {'Pass':11,'Fail':0}
        # fig = px.pie(
        #     hole =0.2,
        #     labels = data_frame.values(),
        #     names = data_frame.keys()           
        # )
        # Category = ['Pass','Fail']
        # fig = px.pie(values=(success,failure), names='Category')    
        labels = ['Pass','Fail']
        values = [success,failure]
        
        colors = ['blue','red']
        

        fig = go.Figure()
        print(9)
        fig.add_trace(go.Pie(labels=labels, values=values, hole=0.3,))    
        fig.update_traces(marker= dict(colors=colors))
        print(10)
        st.header("Doughnut chart")
        st.plotly_chart(fig)      
      


