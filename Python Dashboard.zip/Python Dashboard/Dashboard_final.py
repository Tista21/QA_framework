import xml.etree.ElementTree as ET
import streamlit as st
from xml.dom import minidom
import xmltodict
import json
import plotly as plt
import plotly.graph_objects as go
import plotly.express as px
import base64



st.set_page_config(page_title="My Webpage", page_icon=":tada:", layout="wide")
data = {}
success = 0
failure = 0


#-------header_section------


st.title("welcome to the Dashboard")
st.subheader("browse to choose your XML file")



with st.container():
    uploaded_file = st.sidebar.file_uploader("Upload File",type=['xml'])
    
    print(uploaded_file)      
    if (uploaded_file):
        xmlFile = uploaded_file.read()
        file1_data = json.loads(json.dumps(xmltodict.parse(xmlFile)))
        print('data')
        print(file1_data)
        
        print(3)
        st.write("FileName: ",uploaded_file.name)
        print(4)
        st.write("FileType: ", uploaded_file.type)
        print(5)
        st.write("FileSize: ", uploaded_file.size)        
        print(6,uploaded_file)
        
        #with open(uploaded_file) as xml_file:
        # data = json.load(uploaded_file)

        with st.expander("See test stages"):
            for each in file1_data['testsuite']['testcase']:
                isSuccess = each['@classname'] == 'com.auction.verifications.Feeds'

                output= ''

                if(isSuccess):
                    success += 1
                    output = 'SUCCESS'
                else:
                    failure += 1
                    outptut = 'FAIL'
               

                st.write("* ", each['@name'])
                st.write("> ", output)
                # st.write(root[5][0].tag)
                
        print(7)

        # data_frame = {'Pass':11,'Fail':0}
        # fig = px.pie(
        #     hole =0.2,
        #     labels = data_frame.values(),
        #     names = data_frame.keys()           
        # )
        # Category = ['Pass','Fail']
        # fig = px.pie(values=(success,failure), names='Category')

        labels = ['Pass','Fail']
        values = [success,failure]

        fig = go.Figure()
        print(8)
        fig.add_trace(go.Pie(labels=labels, values=values, hole=0.3))    

        print(9)
        st.header("Doughnut chart")
        st.plotly_chart(fig)      
      
        print(10)





# print(json.dumps(data['testSteps'], indent=4, sort_keys=True))

# print(data['testSteps'])
# print(data.keys())