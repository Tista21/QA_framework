import streamlit as st
import json
import plotly as plt
import plotly.graph_objects as go
import plotly.express as px

st.set_page_config(page_title="My Webpage", page_icon=":tada:", layout="wide")
data = {}
success = 0
failure = 0

#-------header_section------

st.title("welcome to the dashboard")
st.subheader("browse to choose your JSON file")

with st.container():
    uploaded_file = st.sidebar.file_uploader("Upload File",type=['json'])        
    if (uploaded_file):
        st.write("FileName: ",uploaded_file.name)
        st.write("FileType: ", uploaded_file.type)
        st.write("FileSize: ", uploaded_file.size)        
        
        #with open(uploaded_file) as json_file:
        data = json.load(uploaded_file)
        print(uploaded_file)

        with st.expander("See test stages"):
            for each in data['testSteps']:
                st.write("* ", each['description'])
                st.write("> ", each['result'])
                if(each['result']=="SUCCESS"):
                    success += 1
                else:
                    failure += 1

        # data_frame = {'Pass':11,'Fail':0}
        # fig = px.pie(
        #     hole =0.2,
        #     labels = data_frame.values(),
        #     names = data_frame.keys()           
        # )
        # Category = ['Pass','Fail']
        # fig = px.pie(values=(success,failure), names='Category')    

        labels = ['Pass','Fail']
        values = [success,failure]

        fig = go.Figure()
        fig.add_trace(go.Pie(labels=labels, values=values, hole=0.3))    

        st.header("Donut chart")
        st.plotly_chart(fig)





# print(json.dumps(data['testSteps'], indent=4, sort_keys=True))

# print(data['testSteps'])
# print(data.keys())